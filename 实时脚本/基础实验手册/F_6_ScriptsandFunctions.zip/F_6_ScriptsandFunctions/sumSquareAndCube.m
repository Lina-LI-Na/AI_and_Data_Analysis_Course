function f = sumSquareAndCube(x)
 
f = x^2+x^3;

end