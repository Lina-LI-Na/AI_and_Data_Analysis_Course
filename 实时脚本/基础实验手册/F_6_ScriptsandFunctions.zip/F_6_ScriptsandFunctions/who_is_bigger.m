function f = who_is_bigger(a,b)
if a>=b
    f =a;
else
    f=b;
end